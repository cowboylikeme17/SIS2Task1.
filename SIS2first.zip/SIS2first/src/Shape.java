import java.io.Serializable;
abstract class Shape implements Serializable {
    public abstract double calculateArea();
    public abstract String toString();
}